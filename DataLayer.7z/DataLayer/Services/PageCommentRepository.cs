﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer
{
    public class PageCommentRepository : IPageCommentRepository
    {
        private MyCmsContext db;

        public PageCommentRepository(MyCmsContext context)
        {
            this.db = context;
        }

        public IEnumerable<PageComment> GetCommentByPageId(int pageId)
        {
            return db.PageComments.Where(c => c.PageID == pageId);
        }

        public bool InsertPageComment(PageComment pageComment)
        {
            try
            {
                db.PageComments.Add(pageComment);
                db.SaveChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
