﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer
{
    public class LoginRepository : ILoginRepository
    {
        private MyCmsContext db;

        public LoginRepository(MyCmsContext context)
        {
            this.db = context;
        }

        public void Dispose()
        {
            db.Dispose();
        }

        public bool IsExistUser(string username, string password)
        {
            return db.AdminLogins.Any(n => n.UserName == username && n.Password == password);
        }
    }
}
