﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer
{
    public interface IPageRepository:IDisposable
    {
        IEnumerable<Page> GetAllPages();
        Page GetPageById(int pageId);
        bool InsertPage(Page page);
        bool UpdatePage(Page page);
        bool DeletePage(Page page);
        bool DeletePage(int pageId);
        void Save();
        IEnumerable<Page> GetTopPages(int take = 4);
        IEnumerable<Page> ShowInSlider();
        IEnumerable<Page> GetLastestNews(int take = 4);
        IEnumerable<Page> ShowNewsByGroupId(int groupId);
        IEnumerable<Page> GetSearchResult(string search);
    }
}
