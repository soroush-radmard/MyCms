﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer
{
    public interface IPageGroupRepository:IDisposable
    {
        IEnumerable<PageGroup> GetAllGroups();

        PageGroup GetPageGroupById(int groupId);

        bool InsertPageGroup(PageGroup pageGroup);

        bool UpdatePageGroup(PageGroup pageGroup);

        bool DeletePageGroup(int groupId);

        bool DeletePageGroup(PageGroup pageGroup);

        void Save();

        IEnumerable<ShowGroupsViewModel> GetGroupsInView();
    }
}
